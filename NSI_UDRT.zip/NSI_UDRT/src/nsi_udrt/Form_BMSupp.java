/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package nsi_udrt;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import javax.swing.*;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
/**
 *
 * @author Dragneel
 */
public class Form_BMSupp extends javax.swing.JFrame {

    /**
     * Creates new form Form_BMSupp
     */
    private DefaultTableModel model1, 

    /**
     * Creates new form Form_BMSupp
     */
    model2;
    public Form_BMSupp() {
        initComponents();
        setLocationRelativeTo(this);
        this.setTitle("SISTEM INFORMASI UD. RINDI TANI");
        no_masuk();
        kasir();
        supplayer();
        show_time();
        txt_idsupplayer.setText("-");
    }
    public void reset(){
        txt_id.setText("");
        txt_nama.setText("");
        txt_harga.setText("");
        txt_diskon.setText("");
        txt_stok.setText("");
        txt_qty.setText("");
        txt_bayar.setText("");
    }
    public void show_database(){
        Object []baris = {"ID Barang","Nama Barang","Harga Jual","Stok","Supplayer"};
        model1 = new DefaultTableModel(null, baris);
        tbl_daftar.setModel(model1);
            try {
            String sql = "select * from tabel_barang where supplayer_barang = '"+txt_supplayer.getText()+"'";
            Connection con = new Connections_ShowDB().getConnection();
            Statement stat = con.createStatement();
            ResultSet hasil = stat.executeQuery(sql);
                while (hasil.next()){
                    String id = hasil.getString("id_barang");
                    String nama = hasil.getString("nama_barang");
                    String harga = hasil.getString("harga_barang");
                    String stok = hasil.getString("stok_barang");
                    String supplayer = hasil.getString("supplayer_barang");
                    String[] data = {id, nama, harga, stok, supplayer};
                    model1.addRow(data);
                }
            } 
            catch (Exception e) {
            }
    }
    public void show_in(){
        Object []baris = {"ID Barang","Nama Barang","Harga","Diskon","Qty","Sub Total"};
        model2 = new DefaultTableModel(null, baris);
        tbl_masuk.setModel(model2);        
        try {
            String sql = "select * from detail_masuk where id_masuk = '"+txt_masuk.getText()+"' and id_supplayer = '"+txt_idsupplayer.getText()+"'";
            Connection con = new Connections_ShowDB().getConnection();
            Statement stat = con.createStatement();
            ResultSet hasil = stat.executeQuery(sql);                      
              while (hasil.next()){
                String id = hasil.getString("id_barang");
                String nama = hasil.getString("nama_barang");
                String harga = hasil.getString("harga_barang");
                String diskon = hasil.getString("harga_diskon");
                String qty = hasil.getString("qty");
                String subtotal = hasil.getString("sub_total");
                String[] data = {id, nama, harga, diskon, qty, subtotal};
                model2.addRow(data);
              }            
        } catch (Exception e) {
        }
    }
    private void no_masuk(){
    String sql = "select * from tabel_masuk ORDER BY id_masuk DESC";    
       try {
            Connection con = new Connections_ShowDB().getConnection();
            Statement stat = con.createStatement();
            ResultSet hasil = stat.executeQuery(sql);
            if (hasil.next()) {
                String id = hasil.getString("id_masuk").substring(1);
                String AN = "" + (Integer.parseInt(id) + 1);
                String Nol = "";

                if(AN.length()==1)
                {Nol = "000";}
                else if(AN.length()==2)
                {Nol = "00";}
                else if(AN.length()==3)
                {Nol = "0";}
                else if(AN.length()==4)
                {Nol = "";}

               txt_masuk.setText("M" + Nol + AN);
            } else {
               txt_masuk.setText("M0001");
            }

           }catch(Exception e){
           JOptionPane.showMessageDialog(null, e);
           }
     }
    public void show_time(){
        String timeStamp = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(Calendar.getInstance().getTime());
        txt_tanggal.setText(timeStamp);
    }
    public void kasir(){
        try {
            String sql = "SELECT username FROM tabel_login ORDER BY username DESC";
            Connection con = new Connections_ShowDB().getConnection();
            Statement stat = con.createStatement();
            ResultSet hasil = stat.executeQuery(sql);
            while (hasil.next()){
                String user = hasil.getString("username");
                txt_kasir.setText(user);
            }  
        } 
        catch (Exception e) {
            JOptionPane.showMessageDialog(this, e.getMessage());
        }
    }
    public void supplayer(){
        try {
            String sql = "SELECT * FROM tabel_supplayer";
            Connection con = new Connections_ShowDB().getConnection();
            Statement stat = con.createStatement();
            ResultSet hasil = stat.executeQuery(sql);            
            while (hasil.next()) {                
                cb_supplayer.addItem(hasil.getString("nama_supplayer"));
            }             
            hasil.last();
            int jumlahdata = hasil.getRow();
            hasil.first();  
        } 
        catch (Exception e) {
            JOptionPane.showMessageDialog(this, e.getMessage());
        }
    }
    public void id_supplayer(){
        try {
            String sql = "SELECT id_supplayer FROM tabel_supplayer where nama_supplayer = '"+txt_supplayer.getText()+"'";
            Connection con = new Connections_ShowDB().getConnection();
            Statement stat = con.createStatement();
            ResultSet hasil = stat.executeQuery(sql);            
            while (hasil.next()) {                
                String id = hasil.getString("id_supplayer");
                txt_idsupplayer.setText(id);
            }
        } 
        catch (Exception e) {
            JOptionPane.showMessageDialog(this, e.getMessage());
        }
    }
    public void tambah_barang(){
        int harga = Integer.parseInt(txt_harga.getText());
        int diskon = Integer.parseInt(txt_diskon.getText());
        int qty = Integer.parseInt(txt_qty.getText());
        int subtotal = (harga-diskon)*qty; 
        if(txt_supplayer.getText().equals("")){
            JOptionPane.showMessageDialog(null, "Supplayer Belum di Isi");
        }
        else {
            try {
            String sql = "INSERT INTO detail_masuk VALUES (DEFAULT,'"+txt_masuk.getText()+"','"+txt_id.getText()+"','"+txt_idsupplayer.getText()+"','"+txt_nama.getText()+"','"+txt_harga.getText()+"','"+txt_diskon.getText()+"','"+txt_qty.getText()+"','"+subtotal+"')";
            java.sql.Connection conn =(Connection)Connections_Crud.configDB();
            java.sql.PreparedStatement pst = conn.prepareStatement(sql);
            pst.execute();
            } 
        catch (Exception e) {
            JOptionPane.showMessageDialog(this, e.getMessage());
            }
        }
        
    }
    public void hapus(){
        try {
            String sql = "delete from detail_masuk where id_masuk = '"+txt_masuk.getText()+"' and id_barang = '"+txt_id.getText()+"' and qty = '"+txt_qty.getText()+"'";
            java.sql.Connection conn=(Connection)Connections_Crud.configDB();
            java.sql.PreparedStatement pst=conn.prepareStatement(sql);
            pst.execute();
            show_in();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, e.getMessage());
        }
    }
    public void bayar(){
        DefaultTableModel model2 = (DefaultTableModel) tbl_masuk.getModel();
        int jumlah = model2.getRowCount();
        int totalSub = 0;
        
        for (int i = 0; i < jumlah; i++) {
            int dataTotal = Integer.valueOf(model2.getValueAt(i, 5).toString());
            totalSub += dataTotal;
        }
        txt_bayar.setText(Integer.toString(totalSub));
    }
    public void tambah_stok(){
        int stok = Integer.parseInt(txt_stok.getText());
        int qty = Integer.parseInt(txt_qty.getText());
        int sistok = stok+qty;
        try {
            String sql = "UPDATE tabel_barang set stok_barang = '"+sistok+"' where id_barang = '"+txt_id.getText()+"'";
            java.sql.Connection conn =(Connection)Connections_Crud.configDB();
            java.sql.PreparedStatement pst = conn.prepareStatement(sql);
            pst.execute();            
            show_database();
        }       
        catch (Exception e) {
            JOptionPane.showMessageDialog(this, e.getMessage());
            }
    }
    public void kurang_stok(){
        int stok = Integer.parseInt(txt_stok.getText());
        int qty = Integer.parseInt(txt_qty.getText());
        int sistok = stok-qty;
        try {
            String sql = "UPDATE tabel_barang set stok_barang = '"+sistok+"' where id_barang = '"+txt_id.getText()+"'";
            java.sql.Connection conn =(Connection)Connections_Crud.configDB();
            java.sql.PreparedStatement pst = conn.prepareStatement(sql);
            pst.execute();            
            show_database();
        }       
        catch (Exception e) {
            JOptionPane.showMessageDialog(this, e.getMessage());
            }
    }
    public void barang_masuk(){
        if (txt_bayar.getText().equals("")){
            JOptionPane.showMessageDialog(null, "Belum Ada Transaksi");
        }
        else{
            try {
            String sql = "INSERT INTO tabel_masuk VALUES ('"+txt_masuk.getText()+"','"+txt_tanggal.getText()+"','"+txt_supplayer.getText()+"','"+txt_kasir.getText()+"')";
            java.sql.Connection conn =(Connection)Connections_Crud.configDB();
            java.sql.PreparedStatement pst = conn.prepareStatement(sql);
            pst.execute();
            show_in();
            } 
        catch (Exception e) {
            JOptionPane.showMessageDialog(this, e.getMessage());
            }
        }
    }
    public void selectstok(){
        try {
            String sql = "SELECT stok_barang FROM tabel_barang where id_barang = '"+txt_id.getText()+"'";
            Connection con = new Connections_ShowDB().getConnection();
            Statement stat = con.createStatement();
            ResultSet hasil = stat.executeQuery(sql);            
            while (hasil.next()) {                
                String stok = hasil.getString("stok_barang");
                txt_stok.setText(stok);
            }
        } 
        catch (Exception e) {
            JOptionPane.showMessageDialog(this, e.getMessage());
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        btn_back = new javax.swing.JButton();
        btn_transaksi = new javax.swing.JButton();
        btn_bayar = new javax.swing.JButton();
        txt_bayar = new javax.swing.JTextField();
        jLabel12 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        txt_id = new javax.swing.JTextField();
        txt_nama = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        txt_masuk = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        txt_idsupplayer = new javax.swing.JTextField();
        txt_kasir = new javax.swing.JTextField();
        txt_tanggal = new javax.swing.JTextField();
        cb_supplayer = new javax.swing.JComboBox<>();
        txt_supplayer = new javax.swing.JTextField();
        jPanel2 = new javax.swing.JPanel();
        btn_hapus = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        tbl_masuk = new javax.swing.JTable();
        btn_tambah = new javax.swing.JButton();
        txt_qty = new javax.swing.JTextField();
        txt_stok = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        txt_diskon = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        txt_harga = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tbl_daftar = new javax.swing.JTable();
        jLabel4 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(51, 51, 51));

        btn_back.setBackground(new java.awt.Color(0, 204, 204));
        btn_back.setText("Back");
        btn_back.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_backActionPerformed(evt);
            }
        });

        btn_transaksi.setBackground(new java.awt.Color(0, 204, 204));
        btn_transaksi.setText("Transaksi Baru");
        btn_transaksi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_transaksiActionPerformed(evt);
            }
        });

        btn_bayar.setBackground(new java.awt.Color(0, 204, 204));
        btn_bayar.setText("Bayar");
        btn_bayar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_bayarActionPerformed(evt);
            }
        });

        txt_bayar.setEditable(false);
        txt_bayar.setBackground(new java.awt.Color(102, 102, 102));
        txt_bayar.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        txt_bayar.setForeground(new java.awt.Color(255, 255, 255));
        txt_bayar.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        txt_bayar.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(102, 102, 102)));

        jLabel12.setForeground(new java.awt.Color(255, 255, 255));
        jLabel12.setText("Total");

        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("ID Barang");

        txt_id.setEditable(false);
        txt_id.setBackground(new java.awt.Color(102, 102, 102));
        txt_id.setForeground(new java.awt.Color(255, 255, 255));
        txt_id.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(102, 102, 102)));

        txt_nama.setEditable(false);
        txt_nama.setBackground(new java.awt.Color(102, 102, 102));
        txt_nama.setForeground(new java.awt.Color(255, 255, 255));
        txt_nama.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(102, 102, 102)));

        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("Nama Barang");

        jLabel1.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Barang Masuk");

        txt_masuk.setEditable(false);
        txt_masuk.setBackground(new java.awt.Color(102, 102, 102));
        txt_masuk.setForeground(new java.awt.Color(255, 255, 255));
        txt_masuk.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(102, 102, 102)));

        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("ID Masuk");

        jLabel11.setForeground(new java.awt.Color(255, 255, 255));
        jLabel11.setText("Tanggal");

        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("ID Kasir");

        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("Supplayer");

        txt_idsupplayer.setEditable(false);
        txt_idsupplayer.setBackground(new java.awt.Color(102, 102, 102));
        txt_idsupplayer.setForeground(new java.awt.Color(255, 255, 255));
        txt_idsupplayer.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(102, 102, 102)));

        txt_kasir.setEditable(false);
        txt_kasir.setBackground(new java.awt.Color(102, 102, 102));
        txt_kasir.setForeground(new java.awt.Color(255, 255, 255));
        txt_kasir.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(102, 102, 102)));

        txt_tanggal.setEditable(false);
        txt_tanggal.setBackground(new java.awt.Color(102, 102, 102));
        txt_tanggal.setForeground(new java.awt.Color(255, 255, 255));
        txt_tanggal.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(102, 102, 102)));

        cb_supplayer.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "-" }));
        cb_supplayer.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cb_supplayerActionPerformed(evt);
            }
        });

        txt_supplayer.setEditable(false);
        txt_supplayer.setBackground(new java.awt.Color(102, 102, 102));
        txt_supplayer.setForeground(new java.awt.Color(255, 255, 255));
        txt_supplayer.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(102, 102, 102)));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(32, 32, 32)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jLabel2)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                        .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(jLabel5))
                                    .addComponent(jLabel11))
                                .addGap(27, 27, 27)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(txt_tanggal)
                                    .addComponent(txt_kasir)
                                    .addComponent(txt_masuk)
                                    .addComponent(txt_idsupplayer, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addComponent(cb_supplayer, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(txt_supplayer, javax.swing.GroupLayout.Alignment.TRAILING)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel1))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addGap(32, 32, 32)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                .addComponent(btn_back)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(btn_transaksi))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel6)
                                .addGap(18, 18, 18)
                                .addComponent(jLabel7))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(txt_id, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addGap(9, 9, 9)
                                        .addComponent(jLabel12)))
                                .addGap(18, 18, 18)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(txt_bayar)
                                    .addComponent(btn_bayar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(txt_nama))))))
                .addGap(16, 16, 16))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(txt_masuk, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel11)
                    .addComponent(txt_tanggal, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(txt_kasir, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txt_idsupplayer, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5))
                .addGap(18, 18, 18)
                .addComponent(cb_supplayer, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(txt_supplayer, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(23, 23, 23)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(jLabel7))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(txt_nama, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txt_id, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(26, 26, 26)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txt_bayar, javax.swing.GroupLayout.PREFERRED_SIZE, 59, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel12))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btn_bayar)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btn_transaksi)
                    .addComponent(btn_back))
                .addGap(34, 34, 34))
        );

        jPanel2.setBackground(new java.awt.Color(97, 212, 195));

        btn_hapus.setText("Hapus");
        btn_hapus.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_hapusActionPerformed(evt);
            }
        });

        tbl_masuk.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID Barang", "Nama Barang", "Harga", "Diskon", "Qty", "Sub Total"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, true, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tbl_masuk.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tbl_masukMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(tbl_masuk);

        btn_tambah.setText("Tambah Barang");
        btn_tambah.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_tambahActionPerformed(evt);
            }
        });

        txt_stok.setEditable(false);

        jLabel10.setText("Qty");

        jLabel13.setText("Stok");

        txt_diskon.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txt_diskonKeyPressed(evt);
            }
        });

        jLabel9.setText("Diskon");

        txt_harga.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txt_hargaKeyPressed(evt);
            }
        });

        jLabel8.setText("Harga");

        tbl_daftar.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID Barang", "Nama Barang", "Harga Jual", "Stok", "Supplayer"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tbl_daftar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tbl_daftarMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tbl_daftar);

        jLabel4.setText("Stok Gudang");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btn_hapus))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(20, 20, 20)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 582, Short.MAX_VALUE)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(jLabel4)
                                .addGap(0, 0, Short.MAX_VALUE))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(txt_harga, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel8))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(txt_diskon, javax.swing.GroupLayout.PREFERRED_SIZE, 133, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel9))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel13)
                                    .addComponent(txt_stok, javax.swing.GroupLayout.PREFERRED_SIZE, 58, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel2Layout.createSequentialGroup()
                                        .addGap(8, 8, 8)
                                        .addComponent(jLabel10))
                                    .addGroup(jPanel2Layout.createSequentialGroup()
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(txt_qty, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(btn_tambah)))))))
                .addGap(20, 20, 20))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(41, 41, 41)
                .addComponent(jLabel4)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 178, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(20, 20, 20)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8)
                    .addComponent(jLabel9)
                    .addComponent(jLabel13)
                    .addComponent(jLabel10))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txt_harga)
                    .addComponent(txt_diskon, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txt_qty, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txt_stok, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn_tambah))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 206, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btn_hapus)
                .addGap(19, 19, 19))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void cb_supplayerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cb_supplayerActionPerformed
        // TODO add your handling code here:
        String supp = (String)cb_supplayer.getSelectedItem();
        txt_supplayer.setText(supp);
        id_supplayer();
        show_database();
        cb_supplayer.setEnabled(false);
        show_in();
    }//GEN-LAST:event_cb_supplayerActionPerformed

    private void btn_tambahActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_tambahActionPerformed
        // TODO add your handling code here:
        if(txt_harga.getText().equals("")){
            JOptionPane.showMessageDialog(null, "Maaf, Harga belum diisi");
        }else if(txt_diskon.getText().equals("")){
            JOptionPane.showMessageDialog(null, "Maaf, Diskon belum diisi");
        }else if(txt_qty.getText().equals("")){
            JOptionPane.showMessageDialog(null, "Maaf, Quantity belum diisi");
        }else if(Integer.parseInt(txt_harga.getText())<Integer.parseInt(txt_diskon.getText())){
            JOptionPane.showMessageDialog(null, "Harga kurang dari diskon");
        }
        else{
        tambah_barang();
        tambah_stok();
        show_in();
        reset();
        bayar();
        }
    }//GEN-LAST:event_btn_tambahActionPerformed

    private void tbl_daftarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbl_daftarMouseClicked
        // TODO add your handling code here:
        int baris = tbl_daftar.rowAtPoint(evt.getPoint());
        String id = tbl_daftar.getValueAt(baris, 0).toString();
        txt_id.setText(id);
        String nama = tbl_daftar.getValueAt(baris, 1).toString();
        txt_nama.setText(nama);
        String stok = tbl_daftar.getValueAt(baris, 3).toString();
        txt_stok.setText(stok);
        txt_qty.setEnabled(true);
        txt_harga.requestFocus();
        btn_hapus.setEnabled(false);
    }//GEN-LAST:event_tbl_daftarMouseClicked

    private void txt_hargaKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_hargaKeyPressed
        // TODO add your handling code here:
        if(evt.getKeyCode() == evt.VK_ENTER)
        txt_diskon.requestFocus();
    }//GEN-LAST:event_txt_hargaKeyPressed

    private void txt_diskonKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_diskonKeyPressed
        // TODO add your handling code here:
        if(evt.getKeyCode() == evt.VK_ENTER)
        txt_qty.requestFocus();
    }//GEN-LAST:event_txt_diskonKeyPressed

    private void tbl_masukMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbl_masukMouseClicked
        // TODO add your handling code here:
        int baris = tbl_masuk.rowAtPoint(evt.getPoint());
        String id = tbl_masuk.getValueAt(baris, 0).toString();
        txt_id.setText(id);
        String nama = tbl_masuk.getValueAt(baris, 1).toString();
        txt_nama.setText(nama);
        String qty = tbl_masuk.getValueAt(baris, 4).toString();
        txt_qty.setText(qty);
        selectstok();
        txt_qty.setEnabled(false);
        btn_hapus.setEnabled(true);
    }//GEN-LAST:event_tbl_masukMouseClicked

    private void btn_hapusActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_hapusActionPerformed
        // TODO add your handling code here:     
        if(txt_stok.getText().equals("")){
            JOptionPane.showMessageDialog(null, "Maaf, Stok belum diisi");
        }
        else{
        kurang_stok();
        hapus();
        reset();
        }
    }//GEN-LAST:event_btn_hapusActionPerformed

    private void btn_backActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_backActionPerformed
        // TODO add your handling code here:
        Form_Home fh = new Form_Home();
        this.setVisible(false);
        fh.setVisible(true);
    }//GEN-LAST:event_btn_backActionPerformed

    private void btn_bayarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_bayarActionPerformed
        // TODO add your handling code here:
        if(txt_bayar.getText().equals("")){
            JOptionPane.showMessageDialog(null, "Total transaksi kosong");
        }
//        else if(txt_bayar.getText().equals("0")){
//            JOptionPane.showMessageDialog(null, "Total transaksi kosong");
//        }
        else{
        bayar();
        JOptionPane.showMessageDialog(null, "Transaksi Sukses");
        btn_tambah.setEnabled(false);
        btn_bayar.setEnabled(false);
        }
    }//GEN-LAST:event_btn_bayarActionPerformed

    private void btn_transaksiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_transaksiActionPerformed
        // TODO add your handling code here:
        barang_masuk();
        no_masuk();
        show_in();
        reset();
        cb_supplayer.setSelectedItem("-");
        cb_supplayer.setEnabled(true);
        btn_tambah.setEnabled(true);
        btn_bayar.setEnabled(true);
        
    }//GEN-LAST:event_btn_transaksiActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Form_BMSupp.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Form_BMSupp.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Form_BMSupp.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Form_BMSupp.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Form_BMSupp().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn_back;
    private javax.swing.JButton btn_bayar;
    private javax.swing.JButton btn_hapus;
    private javax.swing.JButton btn_tambah;
    private javax.swing.JButton btn_transaksi;
    private javax.swing.JComboBox<String> cb_supplayer;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable tbl_daftar;
    private javax.swing.JTable tbl_masuk;
    private javax.swing.JTextField txt_bayar;
    private javax.swing.JTextField txt_diskon;
    private javax.swing.JTextField txt_harga;
    private javax.swing.JTextField txt_id;
    private javax.swing.JTextField txt_idsupplayer;
    private javax.swing.JTextField txt_kasir;
    private javax.swing.JTextField txt_masuk;
    private javax.swing.JTextField txt_nama;
    private javax.swing.JTextField txt_qty;
    private javax.swing.JTextField txt_stok;
    private javax.swing.JTextField txt_supplayer;
    private javax.swing.JTextField txt_tanggal;
    // End of variables declaration//GEN-END:variables
}
