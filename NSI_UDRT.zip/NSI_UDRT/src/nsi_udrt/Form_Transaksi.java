/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package nsi_udrt;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.*;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import java.util.Date;
import java.util.Calendar;
import java.text.SimpleDateFormat;
/**
 *
 * @author Dragneel
 */
public class Form_Transaksi extends javax.swing.JFrame {

    /**
     * Creates new form Form_Transaksi
     */
    private DefaultTableModel model1, model2;
    public Form_Transaksi() {
        initComponents();
        setLocationRelativeTo(this);
        this.setTitle("SISTEM INFORMASI UD. RINDI TANI");
        show_database();
        show_buy();
        show_time();
        no_transaksi();
        kasir();
        pelanggan();
        txt_pelanggan.setText("-");
        txt_totalbayar.setText("0");
        txt_bayar.setText("0");
        txt_kembalian.setText("0");
    }
    public void reset(){
        txt_idbrg.setText("");
        txt_nmbrg.setText("");
        txt_hrgbrg.setText("");
        txt_dsknbrg.setText("");
        txt_stok.setText("");
        txt_qty.setText("");
        txt_totalbayar.setText("0");
        txt_bayar.setText("0");
        txt_kembalian.setText("0");
    }    

    public void show_database(){
        Object []baris = {"ID Barang","Nama Barang","Harga","Diskon","Stok"};
        model1 = new DefaultTableModel(null, baris);
        tbl_daftar.setModel(model1);
            try {
            String sql = "select * from tabel_barang";
            Connection con = new Connections_ShowDB().getConnection();
            Statement stat = con.createStatement();
            ResultSet hasil = stat.executeQuery(sql);
                while (hasil.next()){
                    String id = hasil.getString("id_barang");
                    String nama = hasil.getString("nama_barang");
                    String harga = hasil.getString("harga_barang");
                    String diskon = hasil.getString("harga_diskon");
                    String stok = hasil.getString("stok_barang");
                    String[] data = {id, nama, harga, diskon, stok};
                    model1.addRow(data);
                }
            } 
            catch (Exception e) {
            }
    }
    
    public void show_buy(){
        Object []baris = {"ID Barang","Nama Barang","Harga","Diskon","Qty","Sub Total"};
        model2 = new DefaultTableModel(null, baris);
        tbl_beli.setModel(model2);        
        try {
            String sql = "select * from detail_transaksi where id_transaksi = '"+txt_transaksi.getText()+"'";
            Connection con = new Connections_ShowDB().getConnection();
            Statement stat = con.createStatement();
            ResultSet hasil = stat.executeQuery(sql);                      
              while (hasil.next()){
                String id = hasil.getString("id_barang");
                String nama = hasil.getString("nama_barang");
                String harga = hasil.getString("harga_barang");
                String diskon = hasil.getString("harga_diskon");
                String qty = hasil.getString("qty");
                String subtotal = hasil.getString("sub_total");
                String[] data = {id, nama, harga, diskon, qty, subtotal};
                model2.addRow(data);
              }            
        } catch (Exception e) {
        }
    }
    
    public void tambah_brgbeli(){
        int harga = Integer.parseInt(txt_hrgbrg.getText());
        int diskon = Integer.parseInt(txt_dsknbrg.getText());
        int qty = Integer.parseInt(txt_qty.getText());
        int subtotal = (harga-diskon)*qty;         
        try {
            String sql = "INSERT INTO detail_transaksi VALUES (DEFAULT,'"+txt_transaksi.getText()+"','"+txt_idbrg.getText()+"','"+txt_nmbrg.getText()+"','"+txt_hrgbrg.getText()+"','"+txt_dsknbrg.getText()+"','"+txt_qty.getText()+"','"+subtotal+"')";
            java.sql.Connection conn =(Connection)Connections_Crud.configDB();
            java.sql.PreparedStatement pst = conn.prepareStatement(sql);
            pst.execute();
            } 
        catch (Exception e) {
            JOptionPane.showMessageDialog(this, e.getMessage());
            }
    }
    public void min_stok(){
        int stok = Integer.parseInt(txt_stok.getText());
        int qty = Integer.parseInt(txt_qty.getText());
        int sistok = stok-qty;
        try {
            String sql = "UPDATE tabel_barang set stok_barang = '"+sistok+"' where id_barang = '"+txt_idbrg.getText()+"'";
            java.sql.Connection conn =(Connection)Connections_Crud.configDB();
            java.sql.PreparedStatement pst = conn.prepareStatement(sql);
            pst.execute();            
            show_database();
        }       
        catch (Exception e) {
            JOptionPane.showMessageDialog(this, e.getMessage());
            }
    }
    public void man_stok(){
        int stok = Integer.parseInt(txt_stok.getText());
        int qty = Integer.parseInt(txt_qty.getText());
        int sistok = stok+qty;
        try {
            String sql = "UPDATE tabel_barang set stok_barang = '"+sistok+"' where id_barang = '"+txt_idbrg.getText()+"'";
            java.sql.Connection conn =(Connection)Connections_Crud.configDB();
            java.sql.PreparedStatement pst = conn.prepareStatement(sql);
            pst.execute();            
            show_database();
        }       
        catch (Exception e) {
            JOptionPane.showMessageDialog(this, e.getMessage());
            }
    }
    
    public void totalbayar(){
        DefaultTableModel model2 = (DefaultTableModel) tbl_beli.getModel();
        int jumlah = model2.getRowCount();
        int totalSub = 0;
        
        for (int i = 0; i < jumlah; i++) {
            int dataTotal = Integer.valueOf(model2.getValueAt(i, 5).toString());
            totalSub += dataTotal;
        }
        txt_totalbayar.setText(Integer.toString(totalSub));
    }
    
    public void bayar(){
        int total = Integer.parseInt(txt_totalbayar.getText());
        int bayar = Integer.parseInt(txt_bayar.getText());
        int kembalian = bayar-total;  
        
        txt_kembalian.setText(Integer.toString(kembalian));
    }
    
    public void hapus_brgbeli(){
        try {
            String sql = "delete from detail_transaksi where id_transaksi = '"+txt_transaksi.getText()+"' and id_barang = '"+txt_idbrg.getText()+"' and qty = '"+txt_qty.getText()+"'";
            java.sql.Connection conn=(Connection)Connections_Crud.configDB();
            java.sql.PreparedStatement pst=conn.prepareStatement(sql);
            pst.execute();
            show_buy();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, e.getMessage());
        }
    }
    
    private void no_transaksi(){
    String sql = "select * from tabel_transaksi ORDER BY id_transaksi DESC";    
       try {
            Connection con = new Connections_ShowDB().getConnection();
            Statement stat = con.createStatement();
            ResultSet hasil = stat.executeQuery(sql);
            if (hasil.next()) {
                String id = hasil.getString("id_transaksi").substring(1);
                String AN = "" + (Integer.parseInt(id) + 1);
                String Nol = "";

                if(AN.length()==1)
                {Nol = "000";}
                else if(AN.length()==2)
                {Nol = "00";}
                else if(AN.length()==3)
                {Nol = "0";}
                else if(AN.length()==4)
                {Nol = "";}

               txt_transaksi.setText("T" + Nol + AN);
            } else {
               txt_transaksi.setText("T0001");
            }

           }catch(Exception e){
           JOptionPane.showMessageDialog(null, e);
           }
     }
    
    public void show_time(){
        String timeStamp = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(Calendar.getInstance().getTime());
        txt_tanggal.setText(timeStamp);
    }
    
    public void kasir(){
        try {
            String sql = "SELECT username FROM tabel_login ORDER BY username DESC";
            Connection con = new Connections_ShowDB().getConnection();
            Statement stat = con.createStatement();
            ResultSet hasil = stat.executeQuery(sql);
            while (hasil.next()){
                String user = hasil.getString("username");
                txt_kasir.setText(user);
            }  
        } 
        catch (Exception e) {
            JOptionPane.showMessageDialog(this, e.getMessage());
        }
    }
    public void pelanggan(){
        try {
            String sql = "SELECT * FROM tabel_kelompok";
            Connection con = new Connections_ShowDB().getConnection();
            Statement stat = con.createStatement();
            ResultSet hasil = stat.executeQuery(sql);            
            while (hasil.next()) {                
                cb_pelanggan.addItem(hasil.getString("nama_kelompok"));
            }             
            hasil.last();
            int jumlahdata = hasil.getRow();
            hasil.first();  
        } 
        catch (Exception e) {
            JOptionPane.showMessageDialog(this, e.getMessage());
        }
    }    
    public void transaksi_baru(){
        if(txt_totalbayar.getText().equals("0")){
            JOptionPane.showMessageDialog(null, "Belum Ada Transaksi");
        }
        else if(txt_bayar.getText().equals("0")){
            JOptionPane.showMessageDialog(null, "Belum ada pembayaran");
        }
        else{
            try {
            String sql = "INSERT INTO tabel_transaksi VALUES('"+txt_transaksi.getText()+"','"+txt_tanggal.getText()+"','"+txt_pelanggan.getText()+"','"+txt_kasir.getText()+"','"+txt_bayar.getText()+"')";
            java.sql.Connection conn =(Connection)Connections_Crud.configDB();
            java.sql.PreparedStatement pst = conn.prepareStatement(sql);
            pst.execute();
            show_buy();
            show_database();
            reset();
            } 
        catch (Exception e) {
            JOptionPane.showMessageDialog(this, e.getMessage());
            }
        }
    }
    public void selectstok(){
        try {
            String sql = "SELECT stok_barang FROM tabel_barang where id_barang = '"+txt_idbrg.getText()+"'";
            Connection con = new Connections_ShowDB().getConnection();
            Statement stat = con.createStatement();
            ResultSet hasil = stat.executeQuery(sql);            
            while (hasil.next()) {                
                String stok = hasil.getString("stok_barang");
                txt_stok.setText(stok);
            }
        } 
        catch (Exception e) {
            JOptionPane.showMessageDialog(this, e.getMessage());
        }
    }
    public void update_barangbeli(){
        try {
            String sql = "UPDATE detail_transaksi set qty = '"+txt_qty.getText()+"' where id_barang = '"+txt_idbrg.getText()+"' and id_transaksi = '"+txt_transaksi.getText()+"'";
            java.sql.Connection conn =(Connection)Connections_Crud.configDB();
            java.sql.PreparedStatement pst = conn.prepareStatement(sql);
            pst.execute();            
            show_database();
        }       
        catch (Exception e) {
            JOptionPane.showMessageDialog(this, e.getMessage());
            }
    }
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane2 = new javax.swing.JScrollPane();
        jTable2 = new javax.swing.JTable();
        jPanel1 = new javax.swing.JPanel();
        btn_back = new javax.swing.JButton();
        btn_transaksibaru = new javax.swing.JButton();
        btn_bayar = new javax.swing.JButton();
        jLabel10 = new javax.swing.JLabel();
        txt_kembalian = new javax.swing.JTextField();
        txt_bayar = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        txt_totalbayar = new javax.swing.JTextField();
        txt_idbrg = new javax.swing.JTextField();
        txt_nmbrg = new javax.swing.JTextField();
        jLabel13 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        txt_kasir = new javax.swing.JTextField();
        cb_pelanggan = new javax.swing.JComboBox<>();
        txt_pelanggan = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        txt_tanggal = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        txt_transaksi = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jLabel7 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tbl_daftar = new javax.swing.JTable();
        txt_hrgbrg = new javax.swing.JTextField();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        txt_dsknbrg = new javax.swing.JTextField();
        jLabel16 = new javax.swing.JLabel();
        txt_stok = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        txt_qty = new javax.swing.JTextField();
        btn_tambah = new javax.swing.JButton();
        jLabel8 = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        tbl_beli = new javax.swing.JTable();
        btn_delete = new javax.swing.JButton();

        jTable2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane2.setViewportView(jTable2);

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(51, 51, 51));

        btn_back.setBackground(new java.awt.Color(0, 204, 204));
        btn_back.setText("Back");
        btn_back.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_backActionPerformed(evt);
            }
        });

        btn_transaksibaru.setBackground(new java.awt.Color(0, 204, 204));
        btn_transaksibaru.setText("Transaksi Baru");
        btn_transaksibaru.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_transaksibaruActionPerformed(evt);
            }
        });

        btn_bayar.setBackground(new java.awt.Color(0, 204, 204));
        btn_bayar.setText("Bayar");
        btn_bayar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_bayarActionPerformed(evt);
            }
        });

        jLabel10.setForeground(new java.awt.Color(255, 255, 255));
        jLabel10.setText("Kembalian");

        txt_kembalian.setEditable(false);
        txt_kembalian.setBackground(new java.awt.Color(102, 102, 102));
        txt_kembalian.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        txt_kembalian.setForeground(new java.awt.Color(255, 255, 255));
        txt_kembalian.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        txt_kembalian.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(102, 102, 102)));

        txt_bayar.setBackground(new java.awt.Color(102, 102, 102));
        txt_bayar.setForeground(new java.awt.Color(255, 255, 255));
        txt_bayar.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        txt_bayar.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(102, 102, 102)));
        txt_bayar.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txt_bayarFocusLost(evt);
            }
        });
        txt_bayar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txt_bayarMouseClicked(evt);
            }
        });

        jLabel9.setForeground(new java.awt.Color(255, 255, 255));
        jLabel9.setText("Bayar");

        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("Total");

        txt_totalbayar.setEditable(false);
        txt_totalbayar.setBackground(new java.awt.Color(102, 102, 102));
        txt_totalbayar.setFont(new java.awt.Font("Tahoma", 0, 36)); // NOI18N
        txt_totalbayar.setForeground(new java.awt.Color(255, 255, 255));
        txt_totalbayar.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        txt_totalbayar.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(102, 102, 102)));

        txt_idbrg.setEditable(false);
        txt_idbrg.setBackground(new java.awt.Color(102, 102, 102));
        txt_idbrg.setForeground(new java.awt.Color(255, 255, 255));
        txt_idbrg.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(102, 102, 102)));

        txt_nmbrg.setEditable(false);
        txt_nmbrg.setBackground(new java.awt.Color(102, 102, 102));
        txt_nmbrg.setForeground(new java.awt.Color(255, 255, 255));
        txt_nmbrg.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(102, 102, 102)));

        jLabel13.setForeground(new java.awt.Color(255, 255, 255));
        jLabel13.setText("Nama Barang");

        jLabel12.setForeground(new java.awt.Color(255, 255, 255));
        jLabel12.setText("ID Barang");

        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("ID Kasir");

        txt_kasir.setEditable(false);
        txt_kasir.setBackground(new java.awt.Color(102, 102, 102));
        txt_kasir.setForeground(new java.awt.Color(255, 255, 255));
        txt_kasir.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(102, 102, 102)));

        cb_pelanggan.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "-" }));
        cb_pelanggan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cb_pelangganActionPerformed(evt);
            }
        });

        txt_pelanggan.setEditable(false);
        txt_pelanggan.setBackground(new java.awt.Color(102, 102, 102));
        txt_pelanggan.setForeground(new java.awt.Color(255, 255, 255));
        txt_pelanggan.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(102, 102, 102)));

        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("Pelanggan");

        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Tanggal Transaksi");

        txt_tanggal.setEditable(false);
        txt_tanggal.setBackground(new java.awt.Color(102, 102, 102));
        txt_tanggal.setForeground(new java.awt.Color(255, 255, 255));
        txt_tanggal.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(102, 102, 102)));

        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("No. Transaksi");

        txt_transaksi.setEditable(false);
        txt_transaksi.setBackground(new java.awt.Color(102, 102, 102));
        txt_transaksi.setForeground(new java.awt.Color(255, 255, 255));
        txt_transaksi.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(102, 102, 102)));

        jLabel1.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Transaksi");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(28, 28, 28)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(btn_back, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(57, 57, 57)
                                .addComponent(btn_transaksibaru, javax.swing.GroupLayout.PREFERRED_SIZE, 172, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(btn_bayar, javax.swing.GroupLayout.PREFERRED_SIZE, 172, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel2)
                                    .addComponent(jLabel3)
                                    .addComponent(jLabel4)
                                    .addComponent(jLabel5)
                                    .addComponent(jLabel12)
                                    .addComponent(txt_idbrg, javax.swing.GroupLayout.PREFERRED_SIZE, 67, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel6)
                                    .addComponent(jLabel9)
                                    .addComponent(jLabel10))
                                .addGap(26, 26, 26)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(cb_pelanggan, 0, 172, Short.MAX_VALUE)
                                    .addComponent(txt_transaksi)
                                    .addComponent(txt_tanggal)
                                    .addComponent(txt_kasir)
                                    .addComponent(txt_pelanggan)
                                    .addComponent(txt_nmbrg)
                                    .addComponent(jLabel13)
                                    .addComponent(txt_totalbayar, javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(txt_bayar, javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(txt_kembalian)))))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel1)))
                .addGap(0, 16, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(txt_transaksi, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(txt_tanggal, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(20, 20, 20)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(txt_pelanggan, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(cb_pelanggan, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(20, 20, 20)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(txt_kasir, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(29, 29, 29)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel12)
                    .addComponent(jLabel13))
                .addGap(5, 5, 5)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txt_idbrg, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txt_nmbrg, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(32, 32, 32)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(txt_totalbayar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel9)
                    .addComponent(txt_bayar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(txt_kembalian, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel10))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btn_bayar)
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btn_transaksibaru)
                    .addComponent(btn_back))
                .addGap(29, 29, 29))
        );

        jPanel2.setBackground(new java.awt.Color(97, 212, 195));

        jLabel7.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel7.setText("Daftar Barang");

        tbl_daftar.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID Barang", "Nama Barang", "Harga", "Diskon", "Stok"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tbl_daftar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tbl_daftarMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tbl_daftar);

        txt_hrgbrg.setEditable(false);

        jLabel14.setText("Harga");

        jLabel15.setText("Diskon");

        txt_dsknbrg.setEditable(false);

        jLabel16.setText("Stok");

        txt_stok.setEditable(false);

        jLabel11.setText("Qty");

        txt_qty.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txt_qtyKeyPressed(evt);
            }
        });

        btn_tambah.setText("Tambah");
        btn_tambah.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_tambahActionPerformed(evt);
            }
        });

        jLabel8.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel8.setText("Barang yang dibeli");

        tbl_beli.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID Barang", "Nama Barang", "Harga", "Diskon", "Qty", "Sub Total"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tbl_beli.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tbl_beliMouseClicked(evt);
            }
        });
        jScrollPane3.setViewportView(tbl_beli);

        btn_delete.setText("Delete");
        btn_delete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_deleteActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel7)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 573, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(btn_delete, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel8)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(txt_hrgbrg, javax.swing.GroupLayout.PREFERRED_SIZE, 166, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel14))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(txt_dsknbrg, javax.swing.GroupLayout.PREFERRED_SIZE, 139, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel15))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel16)
                                    .addComponent(txt_stok, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel2Layout.createSequentialGroup()
                                        .addComponent(txt_qty, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(btn_tambah, javax.swing.GroupLayout.PREFERRED_SIZE, 119, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addComponent(jLabel11)))
                            .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 573, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addContainerGap(23, Short.MAX_VALUE))))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addComponent(jLabel7)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel14)
                    .addComponent(jLabel15)
                    .addComponent(jLabel11)
                    .addComponent(jLabel16))
                .addGap(4, 4, 4)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txt_qty, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txt_stok, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txt_dsknbrg, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn_tambah)
                    .addComponent(txt_hrgbrg, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(8, 8, 8)
                .addComponent(jLabel8)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 183, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(22, 22, 22)
                .addComponent(btn_delete)
                .addContainerGap(37, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel2, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btn_backActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_backActionPerformed
        // TODO add your handling code here:
        Form_Home fh = new Form_Home();
        this.setVisible(false);
        fh.setVisible(true);
    }//GEN-LAST:event_btn_backActionPerformed

    private void btn_tambahActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_tambahActionPerformed
        // TODO add your handling code here:
        if(txt_qty.getText().equals("")){
            JOptionPane.showMessageDialog(null, "Quantity Kosong");
        }else if(Integer.parseInt(txt_stok.getText())<Integer.parseInt(txt_qty.getText())){
            JOptionPane.showMessageDialog(null, "Stok tidak cukup");
        }else{
        //update_barangbeli();
        tambah_brgbeli();
        min_stok();
        totalbayar();
        show_buy();        
        reset();
        totalbayar();
        }        
    }//GEN-LAST:event_btn_tambahActionPerformed

    private void tbl_daftarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbl_daftarMouseClicked
        // TODO add your handling code here:
        int baris = tbl_daftar.rowAtPoint(evt.getPoint());
        String id = tbl_daftar.getValueAt(baris, 0).toString();
        txt_idbrg.setText(id);
        String nama = tbl_daftar.getValueAt(baris,1).toString();
        txt_nmbrg.setText(nama);
        String harga= tbl_daftar.getValueAt(baris, 2).toString();
        txt_hrgbrg.setText(harga);
        if (txt_pelanggan.getText().equals("-")){
            txt_dsknbrg.setText("0");
        }
        else {
        String diskon = tbl_daftar.getValueAt(baris, 3).toString();
        txt_dsknbrg.setText(diskon);
        }
        String stok = tbl_daftar.getValueAt(baris, 4).toString();
        txt_stok.setText(stok);
        txt_qty.setEnabled(true);
        btn_tambah.setEnabled(true);
        btn_delete.setEnabled(false);
    }//GEN-LAST:event_tbl_daftarMouseClicked

    private void btn_bayarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_bayarActionPerformed
        // TODO add your handling code here:
        
        int tb = Integer.parseInt(txt_totalbayar.getText());
        int b = Integer.parseInt(txt_bayar.getText());        
        if(tb>b){
            JOptionPane.showMessageDialog(null, "Uang tidak cukup");
        }        
        else if(b==0){
            JOptionPane.showMessageDialog(null, "Uang tidak cukup");
        }        
        else{
        bayar();
        btn_tambah.setEnabled(false);
        txt_bayar.setEnabled(false);
        }
    }//GEN-LAST:event_btn_bayarActionPerformed

    private void btn_deleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_deleteActionPerformed
        // TODO add your handling code here:
        if(txt_idbrg.getText().equals("")){
            JOptionPane.showMessageDialog(null, "Maaf, Barang belum dipilih");
        }
        else if(txt_stok.getText().equals("")){
            JOptionPane.showMessageDialog(null, "Maaf, Stok belum diisi");
        }
        else{
        kasir();
        hapus_brgbeli();
        man_stok();
        reset();
        totalbayar();
        }
    }//GEN-LAST:event_btn_deleteActionPerformed

    private void tbl_beliMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbl_beliMouseClicked
        // TODO add your handling code here:
        int baris = tbl_beli.rowAtPoint(evt.getPoint());
        String id = tbl_beli.getValueAt(baris, 0).toString();
        txt_idbrg.setText(id);
        String nama = tbl_beli.getValueAt(baris,1).toString();
        txt_nmbrg.setText(nama);
        String harga= tbl_beli.getValueAt(baris, 2).toString();
        txt_hrgbrg.setText(harga);
        String diskon = tbl_beli.getValueAt(baris, 3).toString();
        txt_dsknbrg.setText(diskon);
        String qty = tbl_beli.getValueAt(baris, 4).toString();
        txt_qty.setText(qty);
        selectstok();
        txt_qty.setEnabled(false);
        btn_tambah.setEnabled(false);
        btn_delete.setEnabled(true);
    }//GEN-LAST:event_tbl_beliMouseClicked

    private void cb_pelangganActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cb_pelangganActionPerformed
        // TODO add your handling code here:
        String pelanggan = (String)cb_pelanggan.getSelectedItem();
        txt_pelanggan.setText(pelanggan);
        cb_pelanggan.setEnabled(false);
        show_buy();
    }//GEN-LAST:event_cb_pelangganActionPerformed

    private void btn_transaksibaruActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_transaksibaruActionPerformed
        // TODO add your handling code here:
        transaksi_baru();
        no_transaksi(); 
        show_buy();
        show_database();
        reset();        
        cb_pelanggan.setSelectedItem("-");
        cb_pelanggan.setEnabled(true);
        btn_tambah.setEnabled(true);
        txt_bayar.setEnabled(true);
    }//GEN-LAST:event_btn_transaksibaruActionPerformed

    private void txt_qtyKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_qtyKeyPressed
        // TODO add your handling code here:
        if(evt.getKeyCode() == evt.VK_ENTER){
            tambah_brgbeli();
            show_buy();
            min_stok();
            reset();
        }
    }//GEN-LAST:event_txt_qtyKeyPressed

    private void txt_bayarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txt_bayarMouseClicked
        // TODO add your handling code here:
        if(txt_bayar.getText().equals("0")){
            txt_bayar.setText("");
        }
    }//GEN-LAST:event_txt_bayarMouseClicked

    private void txt_bayarFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txt_bayarFocusLost
        // TODO add your handling code here:
        if(txt_bayar.getText().equals("")){
            txt_bayar.setText("0");
        }
    }//GEN-LAST:event_txt_bayarFocusLost

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Form_Transaksi.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Form_Transaksi.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Form_Transaksi.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Form_Transaksi.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Form_Transaksi().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn_back;
    private javax.swing.JButton btn_bayar;
    private javax.swing.JButton btn_delete;
    private javax.swing.JButton btn_tambah;
    private javax.swing.JButton btn_transaksibaru;
    private javax.swing.JComboBox<String> cb_pelanggan;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JTable jTable2;
    private javax.swing.JTable tbl_beli;
    private javax.swing.JTable tbl_daftar;
    private javax.swing.JTextField txt_bayar;
    private javax.swing.JTextField txt_dsknbrg;
    private javax.swing.JTextField txt_hrgbrg;
    private javax.swing.JTextField txt_idbrg;
    private javax.swing.JTextField txt_kasir;
    private javax.swing.JTextField txt_kembalian;
    private javax.swing.JTextField txt_nmbrg;
    private javax.swing.JTextField txt_pelanggan;
    private javax.swing.JTextField txt_qty;
    private javax.swing.JTextField txt_stok;
    private javax.swing.JTextField txt_tanggal;
    private javax.swing.JTextField txt_totalbayar;
    private javax.swing.JTextField txt_transaksi;
    // End of variables declaration//GEN-END:variables
}
