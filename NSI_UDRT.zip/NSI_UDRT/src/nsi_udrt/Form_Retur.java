/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package nsi_udrt;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import javax.swing.*;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
/**
 *
 * @author Dragneel
 */
public class Form_Retur extends javax.swing.JFrame {

    /**
     * Creates new form Form_Retur
     */
    private DefaultTableModel model1, model2;
    public Form_Retur() {
        initComponents();
        setLocationRelativeTo(this);
        this.setTitle("SISTEM INFORMASI UD. RINDI TANI");
        no_retur();
        show_time();
        kasir();
        supplayer();
        txt_idsupp.setText("-");
        txt_supp.setText("-");
    }
    public void reset(){
        txt_id.setText("");
        txt_nama.setText("");
        txt_stok.setText("");
        txt_qty.setText("");
    }
    public void show_database(){
        Object []baris = {"ID Barang","Nama Barang","Stok","Supplayer"};
        model1 = new DefaultTableModel(null, baris);
        tbl_daftar.setModel(model1);
            try {
            String sql = "select * from tabel_barang where supplayer_barang = '"+txt_supp.getText()+"'";
            Connection con = new Connections_ShowDB().getConnection();
            Statement stat = con.createStatement();
            ResultSet hasil = stat.executeQuery(sql);
                while (hasil.next()){
                    String id = hasil.getString("id_barang");
                    String nama = hasil.getString("nama_barang");
                    String stok = hasil.getString("stok_barang");
                    String supplayer = hasil.getString("supplayer_barang");
                    String[] data = {id, nama, stok, supplayer};
                    model1.addRow(data);
                }
            } 
            catch (Exception e) {
            }
    }
    public void show_in(){
        Object []baris = {"ID Barang","Nama Barang","Qty"};
        model2 = new DefaultTableModel(null, baris);
        tbl_retur.setModel(model2);        
        try {
            String sql = "select * from detail_retur where id_retur = '"+txt_retur.getText()+"' and id_supplayer = '"+txt_idsupp.getText()+"'";
            Connection con = new Connections_ShowDB().getConnection();
            Statement stat = con.createStatement();
            ResultSet hasil = stat.executeQuery(sql);                      
              while (hasil.next()){
                String id = hasil.getString("id_barang");
                String nama = hasil.getString("nama_barang");
                String qty = hasil.getString("qty");
                String[] data = {id, nama, qty};
                model2.addRow(data);
              }            
        } catch (Exception e) {
        }
    }
    private void no_retur(){
    String sql = "select * from tabel_retur ORDER BY id_retur DESC";    
       try {
            Connection con = new Connections_ShowDB().getConnection();
            Statement stat = con.createStatement();
            ResultSet hasil = stat.executeQuery(sql);
            if (hasil.next()) {
                String id = hasil.getString("id_retur").substring(1);
                String AN = "" + (Integer.parseInt(id) + 1);
                String Nol = "";

                if(AN.length()==1)
                {Nol = "000";}
                else if(AN.length()==2)
                {Nol = "00";}
                else if(AN.length()==3)
                {Nol = "0";}
                else if(AN.length()==4)
                {Nol = "";}

               txt_retur.setText("R" + Nol + AN);
            } else {
               txt_retur.setText("R0001");
            }

           }catch(Exception e){
           JOptionPane.showMessageDialog(null, e);
           }
    }
    public void show_time(){
        String timeStamp = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(Calendar.getInstance().getTime());
        txt_tanggal.setText(timeStamp);
    }
    public void kasir(){
        try {
            String sql = "SELECT username FROM tabel_login ORDER BY username DESC";
            Connection con = new Connections_ShowDB().getConnection();
            Statement stat = con.createStatement();
            ResultSet hasil = stat.executeQuery(sql);
            while (hasil.next()){
                String user = hasil.getString("username");
                txt_username.setText(user);
            }  
        } 
        catch (Exception e) {
            JOptionPane.showMessageDialog(this, e.getMessage());
        }
    }
    public void supplayer(){
        try {
            String sql = "SELECT * FROM tabel_supplayer";
            Connection con = new Connections_ShowDB().getConnection();
            Statement stat = con.createStatement();
            ResultSet hasil = stat.executeQuery(sql);            
            while (hasil.next()) {                
                cb_supp.addItem(hasil.getString("nama_supplayer"));
            }             
            hasil.last();
            int jumlahdata = hasil.getRow();
            hasil.first();  
        } 
        catch (Exception e) {
            JOptionPane.showMessageDialog(this, e.getMessage());
        }
    }
    public void id_supplayer(){
        try {
            String sql = "SELECT id_supplayer FROM tabel_supplayer where nama_supplayer = '"+txt_supp.getText()+"'";
            Connection con = new Connections_ShowDB().getConnection();
            Statement stat = con.createStatement();
            ResultSet hasil = stat.executeQuery(sql);            
            while (hasil.next()) {                
                String id = hasil.getString("id_supplayer");
                txt_idsupp.setText(id);
            }
        } 
        catch (Exception e) {
            JOptionPane.showMessageDialog(this, e.getMessage());
        }
    }
    public void tambah_barang(){        
        if(txt_supp.getText().equals("")){
            JOptionPane.showMessageDialog(null, "Supplayer Belum di Isi");
        }
        else {
            try {
            String sql = "INSERT INTO detail_retur VALUES (DEFAULT,'"+txt_retur.getText()+"','"+txt_id.getText()+"','"+txt_idsupp.getText()+"','"+txt_nama.getText()+"','"+txt_qty.getText()+"')";
            java.sql.Connection conn =(Connection)Connections_Crud.configDB();
            java.sql.PreparedStatement pst = conn.prepareStatement(sql);
            pst.execute();
            } 
        catch (Exception e) {
            JOptionPane.showMessageDialog(this, e.getMessage());
            }
        }
    }
    public void hapus(){
        try {
            String sql = "delete from detail_retur where id_retur = '"+txt_retur.getText()+"' and id_barang = '"+txt_id.getText()+"' and qty = '"+txt_qty.getText()+"'";
            java.sql.Connection conn=(Connection)Connections_Crud.configDB();
            java.sql.PreparedStatement pst=conn.prepareStatement(sql);
            pst.execute();
            show_in();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, e.getMessage());
        }
    }
    public void kurang_stok(){
        int stok = Integer.parseInt(txt_stok.getText());
        int qty = Integer.parseInt(txt_qty.getText());
        int sistok = stok-qty;
        try {
            String sql = "UPDATE tabel_barang set stok_barang = '"+sistok+"' where id_barang = '"+txt_id.getText()+"'";
            java.sql.Connection conn =(Connection)Connections_Crud.configDB();
            java.sql.PreparedStatement pst = conn.prepareStatement(sql);
            pst.execute();            
            show_database();
        }       
        catch (Exception e) {
            JOptionPane.showMessageDialog(this, e.getMessage());
            }
    }
    public void tambah_stok(){
        int stok = Integer.parseInt(txt_stok.getText());
        int qty = Integer.parseInt(txt_qty.getText());
        int sistok = stok+qty;
        try {
            String sql = "UPDATE tabel_barang set stok_barang = '"+sistok+"' where id_barang = '"+txt_id.getText()+"'";
            java.sql.Connection conn =(Connection)Connections_Crud.configDB();
            java.sql.PreparedStatement pst = conn.prepareStatement(sql);
            pst.execute();            
            show_database();
        }       
        catch (Exception e) {
            JOptionPane.showMessageDialog(this, e.getMessage());
            }
    }
    public void selectstok(){
        try {
            String sql = "SELECT stok_barang FROM tabel_barang where id_barang = '"+txt_id.getText()+"'";
            Connection con = new Connections_ShowDB().getConnection();
            Statement stat = con.createStatement();
            ResultSet hasil = stat.executeQuery(sql);            
            while (hasil.next()) {                
                String stok = hasil.getString("stok_barang");
                txt_stok.setText(stok);
            }
        } 
        catch (Exception e) {
            JOptionPane.showMessageDialog(this, e.getMessage());
        }
    }
    public void retur(){
        try {
            String sql = "INSERT INTO tabel_retur VALUES ('"+txt_retur.getText()+"','"+txt_tanggal.getText()+"','"+"R"+"','"+txt_supp.getText()+"','"+txt_username.getText()+"')";
            java.sql.Connection conn =(Connection)Connections_Crud.configDB();
            java.sql.PreparedStatement pst = conn.prepareStatement(sql);
            pst.execute();
            show_in();
            } 
        catch (Exception e) {
            JOptionPane.showMessageDialog(this, e.getMessage());
            }
    }
    public void jumlah(){
        DefaultTableModel model2 = (DefaultTableModel) tbl_retur.getModel();
        int jumlah = model2.getRowCount();
        int totalSub = 0;
        
        for (int i = 0; i < jumlah; i++) {
            int dataTotal = Integer.valueOf(model2.getValueAt(i, 2).toString());
            totalSub += dataTotal;
        }
        txt_jumlah.setText(Integer.toString(totalSub));
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        btn_returnew = new javax.swing.JButton();
        txt_back = new javax.swing.JButton();
        txt_nama = new javax.swing.JTextField();
        txt_id = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        cb_supp = new javax.swing.JComboBox<>();
        txt_idsupp = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        txt_username = new javax.swing.JTextField();
        txt_tanggal = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        txt_retur = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        txt_supp = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tbl_daftar = new javax.swing.JTable();
        btn_hapus = new javax.swing.JButton();
        btn_retur = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        tbl_retur = new javax.swing.JTable();
        txt_qty = new javax.swing.JTextField();
        txt_stok = new javax.swing.JTextField();
        btn_tambah = new javax.swing.JButton();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        txt_jumlah = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(51, 51, 51));

        btn_returnew.setText("Retur Baru");
        btn_returnew.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_returnewActionPerformed(evt);
            }
        });

        txt_back.setText("Back");
        txt_back.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_backActionPerformed(evt);
            }
        });

        txt_nama.setEditable(false);
        txt_nama.setBackground(new java.awt.Color(102, 102, 102));
        txt_nama.setForeground(new java.awt.Color(255, 255, 255));
        txt_nama.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(102, 102, 102)));

        txt_id.setEditable(false);
        txt_id.setBackground(new java.awt.Color(102, 102, 102));
        txt_id.setForeground(new java.awt.Color(255, 255, 255));
        txt_id.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(102, 102, 102)));

        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("ID Barang");

        cb_supp.setForeground(new java.awt.Color(255, 255, 255));
        cb_supp.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "-" }));
        cb_supp.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cb_suppActionPerformed(evt);
            }
        });

        txt_idsupp.setEditable(false);
        txt_idsupp.setBackground(new java.awt.Color(102, 102, 102));
        txt_idsupp.setForeground(new java.awt.Color(255, 255, 255));
        txt_idsupp.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(102, 102, 102)));

        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("Supplayer");

        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("ID Kasir");

        txt_username.setEditable(false);
        txt_username.setBackground(new java.awt.Color(102, 102, 102));
        txt_username.setForeground(new java.awt.Color(255, 255, 255));
        txt_username.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(102, 102, 102)));

        txt_tanggal.setEditable(false);
        txt_tanggal.setBackground(new java.awt.Color(102, 102, 102));
        txt_tanggal.setForeground(new java.awt.Color(255, 255, 255));
        txt_tanggal.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(102, 102, 102)));

        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Tanggal");

        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("ID Retur");

        txt_retur.setEditable(false);
        txt_retur.setBackground(new java.awt.Color(102, 102, 102));
        txt_retur.setForeground(new java.awt.Color(255, 255, 255));
        txt_retur.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(102, 102, 102)));

        jLabel1.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Retur");

        txt_supp.setEditable(false);
        txt_supp.setBackground(new java.awt.Color(102, 102, 102));
        txt_supp.setForeground(new java.awt.Color(255, 255, 255));
        txt_supp.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(102, 102, 102)));

        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("Nama Barang");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(21, 21, 21)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel2)
                                    .addComponent(jLabel3)
                                    .addComponent(jLabel4)
                                    .addComponent(jLabel5))
                                .addGap(31, 31, 31)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(cb_supp, javax.swing.GroupLayout.PREFERRED_SIZE, 151, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                        .addComponent(txt_tanggal, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 151, Short.MAX_VALUE)
                                        .addComponent(txt_username, javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(txt_idsupp)
                                        .addComponent(txt_retur))))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addComponent(txt_id, javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel7, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addGap(18, 18, 18)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel8)
                                    .addComponent(txt_nama)))
                            .addComponent(txt_supp, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(txt_back)
                                .addGap(18, 18, 18)
                                .addComponent(btn_returnew)))
                        .addContainerGap(12, Short.MAX_VALUE))))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(txt_retur, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(txt_tanggal, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(txt_username, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(txt_idsupp, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(cb_supp, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(txt_supp, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(jLabel8))
                .addGap(11, 11, 11)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txt_id, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txt_nama, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txt_back)
                    .addComponent(btn_returnew))
                .addGap(26, 26, 26))
        );

        jPanel2.setBackground(new java.awt.Color(97, 212, 195));

        tbl_daftar.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID Barang", "Nama Barang", "Stok", "Supplayer"
            }
        ));
        tbl_daftar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tbl_daftarMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tbl_daftar);

        btn_hapus.setText("Hapus");
        btn_hapus.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_hapusActionPerformed(evt);
            }
        });

        btn_retur.setText("Retur Barang");
        btn_retur.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_returActionPerformed(evt);
            }
        });

        tbl_retur.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID Barang", "Nama Barang", "Qty"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, true, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tbl_retur.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tbl_returMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(tbl_retur);

        txt_stok.setEditable(false);

        btn_tambah.setText("Tambah");
        btn_tambah.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_tambahActionPerformed(evt);
            }
        });

        jLabel9.setText("Qty");

        jLabel10.setText("Stok");

        jLabel11.setText("Daftar Retur");

        txt_jumlah.setEditable(false);

        jLabel6.setText("Jumlah Barang Retur");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                            .addComponent(btn_retur)
                            .addGap(181, 181, 181)
                            .addComponent(jLabel6)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(txt_jumlah, javax.swing.GroupLayout.PREFERRED_SIZE, 62, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                            .addComponent(btn_hapus, javax.swing.GroupLayout.PREFERRED_SIZE, 76, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addComponent(jLabel11)
                        .addGroup(jPanel2Layout.createSequentialGroup()
                            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(txt_stok, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabel10))
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jLabel9)
                                .addGroup(jPanel2Layout.createSequentialGroup()
                                    .addComponent(txt_qty, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                    .addComponent(btn_tambah)))))
                    .addComponent(jScrollPane1)
                    .addComponent(jScrollPane2))
                .addContainerGap(27, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addComponent(jLabel11)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 202, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel10)
                            .addComponent(jLabel9))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txt_stok, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txt_qty, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btn_tambah))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 165, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btn_hapus)
                            .addComponent(btn_retur)))
                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(txt_jumlah, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel6)))
                .addContainerGap(24, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void cb_suppActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cb_suppActionPerformed
        // TODO add your handling code here:
        String supp = (String)cb_supp.getSelectedItem();
        txt_supp.setText(supp);
        id_supplayer();
        show_database();
        cb_supp.setEnabled(false);
        show_in();
    }//GEN-LAST:event_cb_suppActionPerformed

    private void txt_backActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_backActionPerformed
        // TODO add your handling code here:
        Form_Home fh = new Form_Home();
        this.setVisible(false);
        fh.setVisible(true);
    }//GEN-LAST:event_txt_backActionPerformed

    private void btn_returnewActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_returnewActionPerformed
        // TODO add your handling code here:
        cb_supp.setSelectedItem("-");
        txt_idsupp.setText("-");
        cb_supp.setEnabled(true);
        no_retur();
        show_in();
        btn_tambah.setEnabled(true);
        btn_hapus.setEnabled(true);
        btn_retur.setEnabled(true);
        reset();
        txt_jumlah.setText("");
    }//GEN-LAST:event_btn_returnewActionPerformed

    private void btn_tambahActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_tambahActionPerformed
        // TODO add your handling code here:
        if(txt_id.getText().equals("")){
            JOptionPane.showMessageDialog(null, "Maaf, ID Barang belum diisi");
        }else if(txt_nama.getText().equals("")){
            JOptionPane.showMessageDialog(null, "Maaf, Nama Barang belum diisi");
        }else if(txt_stok.getText().equals("")){
            JOptionPane.showMessageDialog(null, "Maaf, Stok Barang belum diisi");
        }else if(txt_qty.getText().equals("")){
            JOptionPane.showMessageDialog(null, "Maaf, Quantity belum diisi");
        }else{
            tambah_barang();
            kurang_stok();
            show_in();
            jumlah();
            reset();
        }
    }//GEN-LAST:event_btn_tambahActionPerformed

    private void tbl_returMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbl_returMouseClicked
        // TODO add your handling code here:
        int baris = tbl_retur.rowAtPoint(evt.getPoint());
        String id = tbl_retur.getValueAt(baris, 0).toString();
        txt_id.setText(id);
        String nama = tbl_retur.getValueAt(baris, 1).toString();
        txt_nama.setText(nama);
        String qty = tbl_retur.getValueAt(baris, 2).toString();
        txt_qty.setText(qty);
        txt_qty.setEnabled(false);
        btn_hapus.setEnabled(true);
        selectstok();
    }//GEN-LAST:event_tbl_returMouseClicked

    private void btn_returActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_returActionPerformed
        // TODO add your handling code here:
        if(txt_supp.getText().equals("-")){
            JOptionPane.showMessageDialog(null, "Supplayer belum di pilih");
        }else if(txt_jumlah.getText().equals("")){
            JOptionPane.showMessageDialog(null, "Belum ada retur");
        }else if(txt_jumlah.getText().equals("0")){
            JOptionPane.showMessageDialog(null, "Belum ada retur");
        }
        else{
            retur();
            btn_tambah.setEnabled(false);
            btn_hapus.setEnabled(false);
            btn_retur.setEnabled(false);
            JOptionPane.showMessageDialog(null, "Retur berhasil");
        }
    }//GEN-LAST:event_btn_returActionPerformed

    private void btn_hapusActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_hapusActionPerformed
        // TODO add your handling code here:
        int jumlah = Integer.parseInt(txt_jumlah.getText());
        int qty = Integer.parseInt(txt_qty.getText());
        int total = jumlah-qty;
        hapus();
        tambah_stok();
        txt_jumlah.setText(Integer.toString(total));
        reset();
    }//GEN-LAST:event_btn_hapusActionPerformed

    private void tbl_daftarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbl_daftarMouseClicked
        // TODO add your handling code here:
        int baris = tbl_daftar.rowAtPoint(evt.getPoint());
        String id = tbl_daftar.getValueAt(baris, 0).toString();
        txt_id.setText(id);
        String nama = tbl_daftar.getValueAt(baris, 1).toString();
        txt_nama.setText(nama);
        String stok = tbl_daftar.getValueAt(baris, 2).toString();
        txt_stok.setText(stok);
        txt_qty.setEnabled(true);
        btn_hapus.setEnabled(false);
    }//GEN-LAST:event_tbl_daftarMouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Form_Retur.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Form_Retur.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Form_Retur.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Form_Retur.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Form_Retur().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn_hapus;
    private javax.swing.JButton btn_retur;
    private javax.swing.JButton btn_returnew;
    private javax.swing.JButton btn_tambah;
    private javax.swing.JComboBox<String> cb_supp;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable tbl_daftar;
    private javax.swing.JTable tbl_retur;
    private javax.swing.JButton txt_back;
    private javax.swing.JTextField txt_id;
    private javax.swing.JTextField txt_idsupp;
    private javax.swing.JTextField txt_jumlah;
    private javax.swing.JTextField txt_nama;
    private javax.swing.JTextField txt_qty;
    private javax.swing.JTextField txt_retur;
    private javax.swing.JTextField txt_stok;
    private javax.swing.JTextField txt_supp;
    private javax.swing.JTextField txt_tanggal;
    private javax.swing.JTextField txt_username;
    // End of variables declaration//GEN-END:variables
}
